const express = require('express');
const router = express.Router();
const withdrawalController = require('../controllers/withdrawal.controller');
const { requireAuth } = require('../middleware/auth.middleware');

router.post('/preview-fee', requireAuth, withdrawalController.previewFee);
router.post('/', requireAuth, withdrawalController.createWithdrawal);
router.get('/', requireAuth, withdrawalController.listMyWithdrawals);
router.get('/:id/receipt', requireAuth, withdrawalController.getReceipt);

module.exports = router;