const express = require('express');
const router = express.Router();
const ownerController = require('../controllers/owner.controller');
const { requireAdminSession } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/role.middleware');
const { ROLES } = require('../config/constants');

router.use(requireAdminSession, requireRole(ROLES.OWNER));

router.post('/admins', ownerController.createAdmin);
router.delete('/admins/:id', ownerController.deleteAdmin);
router.patch('/fees', ownerController.updateFees);
router.patch('/maintenance', ownerController.updateMaintenance);
router.post('/balance-adjustment', ownerController.balanceAdjustment);
router.get('/finance-dashboard', ownerController.financeDashboard);

module.exports = router;