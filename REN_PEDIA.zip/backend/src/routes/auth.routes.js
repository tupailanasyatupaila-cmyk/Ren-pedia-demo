const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { authLimiter, otpLimiter } = require('../middleware/rateLimit.middleware');

router.post('/register', authLimiter, authController.register);
router.post('/verify-otp', otpLimiter, authController.verifyOtp);
router.post('/login', authLimiter, authController.login);
router.post('/logout', authController.logout);
router.post('/forgot-password', otpLimiter, authController.forgotPassword);
router.post('/reset-password', otpLimiter, authController.resetPassword);

module.exports = router;