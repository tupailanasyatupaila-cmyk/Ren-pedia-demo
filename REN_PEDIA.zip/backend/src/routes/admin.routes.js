const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { requireAdminSession } = require('../middleware/auth.middleware');
const { requireRole } = require('../middleware/role.middleware');
const { ROLES } = require('../config/constants');

router.use(requireAdminSession, requireRole(ROLES.ADMIN, ROLES.OWNER));

router.get('/users', adminController.listUsers);
router.post('/users/:id/freeze', adminController.freezeUser);
router.post('/users/:id/unfreeze', adminController.unfreezeUser);
router.post('/users/:id/ban', adminController.banUser);
router.post('/users/:id/unban', adminController.unbanUser);

router.get('/deposits', adminController.listDeposits);
router.post('/deposits/:id/approve', adminController.approveDeposit);
router.post('/deposits/:id/reject', adminController.rejectDeposit);

router.get('/withdrawals', adminController.listWithdrawals);
router.post('/withdrawals/:id/approve', adminController.approveWithdrawal);
router.post('/withdrawals/:id/reject', adminController.rejectWithdrawal);

module.exports = router;