const express = require('express');
const router = express.Router();
const depositController = require('../controllers/deposit.controller');
const { requireAuth } = require('../middleware/auth.middleware');
const upload = require('../middleware/upload.middleware');

router.post('/', requireAuth, depositController.createAutoDeposit);
router.post('/manual', requireAuth, depositController.createManualDeposit);
router.post('/manual/:id/proof', requireAuth, upload.single('proof'), depositController.uploadProof);

module.exports = router;