const pool = require('../db/pool');
const { verifyPassword } = require('../utils/hash');
const audit = require('../services/audit.service');
const { success, fail } = require('../utils/responseFormatter');

async function adminLogin(req, res, next) {
  try {
    const { username, password } = req.body;
    const { rows } = await pool.query(`SELECT * FROM admins WHERE username = $1`, [username]);
    const admin = rows[0];

    if (!admin || admin.is_disabled) return fail(res, 'Username atau password salah', 401);

    const match = await verifyPassword(admin.password_hash, password);
    if (!match) return fail(res, 'Username atau password salah', 401);

    req.session.adminId = admin.id;
    req.session.role = admin.role; // 'ADMIN' atau 'OWNER'

    await audit.log({ actorId: admin.id, actorRole: admin.role, action: 'login', req });
    return success(res, { username: admin.username, role: admin.role }, 'Login berhasil');
  } catch (err) {
    next(err);
  }
}

module.exports = { adminLogin };