const authService = require('../services/auth.service');
const { success, fail } = require('../utils/responseFormatter');

async function register(req, res, next) {
  try {
    const { name, username, email, password, confirmPassword } = req.body;
    if (password !== confirmPassword) return fail(res, 'Password tidak cocok');
    const user = await authService.register({ name, username, email, password });
    return success(res, { userId: user.id }, 'Registrasi berhasil, cek email untuk kode OTP');
  } catch (err) {
    next(err);
  }
}

async function verifyOtp(req, res, next) {
  try {
    const { email, code } = req.body;
    await authService.verifyRegistrationOtp({ email, code });
    return success(res, {}, 'Verifikasi berhasil, silakan login');
  } catch (err) {
    next(err);
  }
}

async function login(req, res, next) {
  try {
    const { username, password } = req.body;
    const user = await authService.login({ username, password });
    req.session.userId = user.id;
    req.session.role = 'USER';
    return success(res, { user }, 'Login berhasil');
  } catch (err) {
    next(err);
  }
}

async function logout(req, res, next) {
  try {
    req.session.destroy(() => {
      res.clearCookie('connect.sid');
      return success(res, {}, 'Logout berhasil');
    });
  } catch (err) {
    next(err);
  }
}

async function forgotPassword(req, res, next) {
  try {
    const { email } = req.body;
    await authService.requestPasswordReset(email);
    return success(res, {}, 'Jika email terdaftar, kode OTP telah dikirim');
  } catch (err) {
    next(err);
  }
}

async function resetPassword(req, res, next) {
  try {
    const { email, code, newPassword } = req.body;
    await authService.resetPassword({ email, code, newPassword });
    return success(res, {}, 'Password berhasil diubah, silakan login');
  } catch (err) {
    next(err);
  }
}

module.exports = { register, verifyOtp, login, logout, forgotPassword, resetPassword };