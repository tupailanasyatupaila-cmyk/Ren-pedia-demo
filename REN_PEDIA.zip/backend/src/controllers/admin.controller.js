const pool = require('../db/pool');
const withdrawalService = require('../services/withdrawal.service');
const audit = require('../services/audit.service');
const { success, fail } = require('../utils/responseFormatter');

async function listUsers(req, res, next) {
  try {
    const { rows } = await pool.query(
      `SELECT u.id, u.name, u.username, u.email, u.is_verified, u.is_frozen, u.is_banned,
              b.balance, u.created_at
       FROM users u LEFT JOIN user_balances b ON b.user_id = u.id
       ORDER BY u.created_at DESC`
    );
    return success(res, rows);
  } catch (err) {
    next(err);
  }
}

async function freezeUser(req, res, next) {
  try {
    const { id } = req.params;
    await pool.query(`UPDATE users SET is_frozen = TRUE WHERE id = $1`, [id]);
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'user freeze', targetType: 'user', targetId: id, req });
    return success(res, {}, 'User dibekukan');
  } catch (err) {
    next(err);
  }
}

async function unfreezeUser(req, res, next) {
  try {
    const { id } = req.params;
    await pool.query(`UPDATE users SET is_frozen = FALSE WHERE id = $1`, [id]);
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'user unfreeze', targetType: 'user', targetId: id, req });
    return success(res, {}, 'User diaktifkan kembali');
  } catch (err) {
    next(err);
  }
}

async function banUser(req, res, next) {
  try {
    const { id } = req.params;
    await pool.query(`UPDATE users SET is_banned = TRUE WHERE id = $1`, [id]);
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'user ban', targetType: 'user', targetId: id, req });
    return success(res, {}, 'User dibanned');
  } catch (err) {
    next(err);
  }
}

async function unbanUser(req, res, next) {
  try {
    const { id } = req.params;
    await pool.query(`UPDATE users SET is_banned = FALSE WHERE id = $1`, [id]);
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'user unban', targetType: 'user', targetId: id, req });
    return success(res, {}, 'User di-unban');
  } catch (err) {
    next(err);
  }
}

async function listDeposits(req, res, next) {
  try {
    const { rows } = await pool.query(
      `SELECT t.id, t.user_id, u.username, u.email, t.amount, t.method, t.status, t.created_at,
              p.proof_image_url
       FROM transactions t
       JOIN users u ON u.id = t.user_id
       LEFT JOIN payments p ON p.transaction_id = t.id
       WHERE t.type = 'deposit' AND t.method = 'qris_manual'
       ORDER BY t.created_at DESC`
    );
    return success(res, rows);
  } catch (err) {
    next(err);
  }
}

async function approveDeposit(req, res, next) {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    await client.query('BEGIN');

    const txRes = await client.query(
      `SELECT * FROM transactions WHERE id = $1 AND status = 'PENDING' FOR UPDATE`,
      [id]
    );
    const tx = txRes.rows[0];
    if (!tx) throw Object.assign(new Error('Transaksi tidak ditemukan atau sudah diproses'), { status: 404 });

    const { applyLedgerChange } = require('../services/ledger.service');
    await applyLedgerChange(client, {
      userId: tx.user_id,
      transactionId: tx.id,
      type: 'deposit',
      amount: Number(tx.amount),
      description: 'Deposit QRIS manual disetujui',
    });

    await client.query(`UPDATE transactions SET status = 'SUCCESS', updated_at = now() WHERE id = $1`, [id]);
    await client.query(
      `UPDATE payments SET reviewed_by = $1, reviewed_at = now() WHERE transaction_id = $2`,
      [req.session.adminId, id]
    );

    await client.query('COMMIT');
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'payment approved', targetType: 'transaction', targetId: id, req });

    return success(res, {}, 'Deposit disetujui');
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}

async function rejectDeposit(req, res, next) {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    await pool.query(`UPDATE transactions SET status = 'REJECTED', updated_at = now() WHERE id = $1`, [id]);
    await pool.query(
      `UPDATE payments SET reviewed_by = $1, reviewed_at = now(), reject_reason = $2 WHERE transaction_id = $3`,
      [req.session.adminId, reason, id]
    );

    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'payment rejected', targetType: 'transaction', targetId: id, metadata: { reason }, req });
    return success(res, {}, 'Deposit ditolak');
  } catch (err) {
    next(err);
  }
}

async function listWithdrawals(req, res, next) {
  try {
    const { rows } = await pool.query(
      `SELECT w.id, t.id as transaction_id, u.username, w.destination_name, w.destination_number,
              t.amount, t.fee, t.net_amount, t.method, w.status, t.created_at
       FROM withdrawals w
       JOIN transactions t ON t.id = w.transaction_id
       JOIN users u ON u.id = t.user_id
       WHERE w.status = 'PENDING'
       ORDER BY t.created_at DESC`
    );
    return success(res, rows);
  } catch (err) {
    next(err);
  }
}

async function approveWithdrawal(req, res, next) {
  try {
    const { id } = req.params;
    const result = await withdrawalService.approveWithdrawal({ withdrawalId: id, adminId: req.session.adminId });
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'withdrawal approved', targetType: 'withdrawal', targetId: id, req });
    return success(res, result, 'Withdrawal disetujui');
  } catch (err) {
    next(err);
  }
}

async function rejectWithdrawal(req, res, next) {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    await withdrawalService.rejectWithdrawal({ withdrawalId: id, adminId: req.session.adminId, reason });
    await audit.log({ actorId: req.session.adminId, actorRole: req.session.role, action: 'withdrawal rejected', targetType: 'withdrawal', targetId: id, metadata: { reason }, req });
    return success(res, {}, 'Withdrawal ditolak, saldo dikembalikan');
  } catch (err) {
    next(err);
  }
}

module.exports = {
  listUsers, freezeUser, unfreezeUser, banUser, unbanUser,
  listDeposits, approveDeposit, rejectDeposit,
  listWithdrawals, approveWithdrawal, rejectWithdrawal,
};