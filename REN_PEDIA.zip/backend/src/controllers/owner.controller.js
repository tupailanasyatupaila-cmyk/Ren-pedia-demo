const pool = require('../db/pool');
const { hashPassword } = require('../utils/hash');
const audit = require('../services/audit.service');
const { success, fail } = require('../utils/responseFormatter');

async function createAdmin(req, res, next) {
  try {
    const { username, password, permissions } = req.body;
    const passwordHash = await hashPassword(password);

    const { rows } = await pool.query(
      `INSERT INTO admins (username, password_hash, role, permissions)
       VALUES ($1, $2, 'ADMIN', $3) RETURNING id, username`,
      [username, passwordHash, JSON.stringify(permissions || [])]
    );

    await audit.log({ actorId: req.session.adminId, actorRole: 'OWNER', action: 'admin created', targetType: 'admin', targetId: rows[0].id, req });
    return success(res, rows[0], 'Admin berhasil dibuat');
  } catch (err) {
    next(err);
  }
}

async function deleteAdmin(req, res, next) {
  try {
    const { id } = req.params;
    await pool.query(`DELETE FROM admins WHERE id = $1 AND role != 'OWNER'`, [id]);
    await audit.log({ actorId: req.session.adminId, actorRole: 'OWNER', action: 'admin deleted', targetType: 'admin', targetId: id, req });
    return success(res, {}, 'Admin dihapus');
  } catch (err) {
    next(err);
  }
}

async function updateFees(req, res, next) {
  try {
    const { ewallet, bank, manual } = req.body;
    await pool.query(
      `INSERT INTO settings (key, value) VALUES ('withdrawal_fee', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = now()`,
      [{ ewallet, bank, manual }]
    );
    await audit.log({ actorId: req.session.adminId, actorRole: 'OWNER', action: 'fee changed', metadata: { ewallet, bank, manual }, req });
    return success(res, {}, 'Fee berhasil diperbarui');
  } catch (err) {
    next(err);
  }
}

async function updateMaintenance(req, res, next) {
  try {
    const { enabled, message } = req.body;
    await pool.query(
      `INSERT INTO settings (key, value) VALUES ('maintenance', $1)
       ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = now()`,
      [{ enabled, message }]
    );
    await audit.log({ actorId: req.session.adminId, actorRole: 'OWNER', action: 'maintenance changed', metadata: { enabled }, req });
    return success(res, {}, 'Maintenance mode diperbarui');
  } catch (err) {
    next(err);
  }
}

async function balanceAdjustment(req, res, next) {
  const client = await pool.connect();
  try {
    const { userId, amount, reason } = req.body;
    if (!amount || !reason) return fail(res, 'Amount dan reason wajib diisi');

    await client.query('BEGIN');
    const { applyLedgerChange } = require('../services/ledger.service');
    const result = await applyLedgerChange(client, {
      userId, transactionId: null, type: 'manual_adjustment', amount, description: reason,
    });
    await client.query('COMMIT');

    await audit.log({
      actorId: req.session.adminId, actorRole: 'OWNER', action: 'balance adjustment',
      targetType: 'user', targetId: userId, metadata: { amount, reason, ...result }, req,
    });

    return success(res, result, 'Saldo berhasil disesuaikan');
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}

async function financeDashboard(req, res, next) {
  try {
    const stats = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM users WHERE is_banned = FALSE) as active_users,
        (SELECT COUNT(*) FROM users WHERE is_banned = TRUE) as banned_users,
        (SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='deposit' AND status='SUCCESS') as total_deposit,
        (SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='withdrawal' AND status='SUCCESS') as total_withdrawal,
        (SELECT COALESCE(SUM(fee),0) FROM transactions WHERE type='withdrawal' AND status='SUCCESS') as total_platform_fee,
        (SELECT COUNT(*) FROM transactions WHERE type='deposit' AND status='PENDING') as pending_deposit,
        (SELECT COUNT(*) FROM withdrawals WHERE status='PENDING') as pending_withdrawal
    `);
    return success(res, stats.rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { createAdmin, deleteAdmin, updateFees, updateMaintenance, balanceAdjustment, financeDashboard };