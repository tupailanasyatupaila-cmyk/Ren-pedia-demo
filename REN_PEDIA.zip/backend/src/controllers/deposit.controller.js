const pool = require('../db/pool');
const { applyLedgerChange } = require('../services/ledger.service');
const qrisService = require('../services/qris.service');
const audit = require('../services/audit.service');
const { success, fail } = require('../utils/responseFormatter');

// Deposit via QRIS otomatis
async function createAutoDeposit(req, res, next) {
  const client = await pool.connect();
  try {
    const userId = req.session.userId;
    const { amount } = req.body;

    if (!amount || amount <= 0) return fail(res, 'Nominal tidak valid');

    const txRes = await client.query(
      `INSERT INTO transactions (user_id, type, method, amount, status)
       VALUES ($1, 'deposit', 'qris_auto', $2, 'PENDING') RETURNING id`,
      [userId, amount]
    );
    const transactionId = txRes.rows[0].id;

    const qris = await qrisService.createAutoQrisPayment({ amount, transactionId });

    await client.query(
      `UPDATE transactions SET provider_ref = $1, metadata = $2 WHERE id = $3`,
      [qris.providerRef, { qrImageUrl: qris.qrImageUrl, expiresAt: qris.expiresAt }, transactionId]
    );

    return success(res, { transactionId, qr: qris }, 'QRIS berhasil dibuat');
  } catch (err) {
    next(err);
  } finally {
    client.release();
  }
}

// Deposit via QRIS manual
async function createManualDeposit(req, res, next) {
  try {
    const userId = req.session.userId;
    const { amount } = req.body;
    if (!amount || amount <= 0) return fail(res, 'Nominal tidak valid');

    const userRes = await pool.query(`SELECT name FROM users WHERE id = $1`, [userId]);
    const merchantName = userRes.rows[0].name;

    const txRes = await pool.query(
      `INSERT INTO transactions (user_id, type, method, amount, status)
       VALUES ($1, 'deposit', 'qris_manual', $2, 'PENDING') RETURNING id`,
      [userId, amount]
    );
    const transactionId = txRes.rows[0].id;

    await pool.query(
      `INSERT INTO payments (transaction_id, mode) VALUES ($1, 'manual')`,
      [transactionId]
    );

    const qris = qrisService.getManualQrisInfo(merchantName);
    return success(res, { transactionId, qris }, 'Silakan bayar lalu upload bukti pembayaran');
  } catch (err) {
    next(err);
  }
}

// Upload bukti pembayaran (manual)
async function uploadProof(req, res, next) {
  try {
    const { id } = req.params;
    if (!req.file) return fail(res, 'File bukti pembayaran wajib diupload');

    const proofUrl = `/uploads/${req.file.filename}`;

    await pool.query(
      `UPDATE payments SET proof_image_url = $1 WHERE transaction_id = $2`,
      [proofUrl, id]
    );

    await audit.log({
      actorId: req.session.userId,
      actorRole: 'USER',
      action: 'manual payment uploaded',
      targetType: 'transaction',
      targetId: id,
      req,
    });

    return success(res, {}, 'Bukti pembayaran berhasil diupload, menunggu review admin');
  } catch (err) {
    next(err);
  }
}

module.exports = { createAutoDeposit, createManualDeposit, uploadProof };