const pool = require('../db/pool');
const withdrawalService = require('../services/withdrawal.service');
const audit = require('../services/audit.service');
const { success, fail } = require('../utils/responseFormatter');

async function previewFee(req, res, next) {
  try {
    const { method, amount } = req.body;
    if (!amount || amount <= 0) return fail(res, 'Nominal tidak valid');
    const { fee, netAmount } = withdrawalService.calculateFee(method, amount);
    return success(res, { fee, netAmount, amount });
  } catch (err) {
    next(err);
  }
}

async function createWithdrawal(req, res, next) {
  try {
    const userId = req.session.userId;
    const { method, destinationName, destinationNumber, amount } = req.body;

    if (!amount || amount <= 0) return fail(res, 'Nominal tidak valid');
    if (!destinationName || !destinationNumber) return fail(res, 'Data tujuan wajib diisi');

    const result = await withdrawalService.createWithdrawal({
      userId, method, destinationName, destinationNumber, amount,
    });

    await audit.log({
      actorId: userId, actorRole: 'USER', action: 'withdrawal created',
      targetType: 'withdrawal', targetId: result.withdrawalId, req,
    });

    return success(res, result, 'Withdrawal diajukan, menunggu diproses');
  } catch (err) {
    next(err);
  }
}

async function listMyWithdrawals(req, res, next) {
  try {
    const userId = req.session.userId;
    const { rows } = await pool.query(
      `SELECT w.*, t.amount, t.fee, t.net_amount, t.status as tx_status, t.created_at
       FROM withdrawals w JOIN transactions t ON t.id = w.transaction_id
       WHERE t.user_id = $1 ORDER BY t.created_at DESC`,
      [userId]
    );
    return success(res, rows);
  } catch (err) {
    next(err);
  }
}

async function getReceipt(req, res, next) {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT r.*, w.destination_name, w.destination_number, t.amount, t.fee, t.net_amount, t.method, u.username
       FROM receipts r
       JOIN withdrawals w ON w.id = r.withdrawal_id
       JOIN transactions t ON t.id = w.transaction_id
       JOIN users u ON u.id = t.user_id
       WHERE w.id = $1`,
      [id]
    );
    if (rows.length === 0) return fail(res, 'Receipt tidak ditemukan', 404);
    return success(res, rows[0]);
  } catch (err) {
    next(err);
  }
}

module.exports = { previewFee, createWithdrawal, listMyWithdrawals, getReceipt };