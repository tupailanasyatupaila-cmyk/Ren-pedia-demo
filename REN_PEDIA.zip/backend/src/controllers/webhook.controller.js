const pool = require('../db/pool');
const { applyLedgerChange } = require('../services/ledger.service');
const { webhookSecret } = require('../config/env');
const { success, fail } = require('../utils/responseFormatter');

// ⚠️ Verifikasi signature di bawah masih generic — sesuaikan header/skema
// signature dengan dokumentasi resmi buatqris.site begitu tersedia.
async function handleQrisWebhook(req, res, next) {
  const client = await pool.connect();
  try {
    const signature = req.headers['x-webhook-signature'];
    if (signature !== webhookSecret) {
      return fail(res, 'Signature tidak valid', 401);
    }

    const { event_id, reference_id, amount, status } = req.body;
    if (!event_id || !reference_id || !amount || !status) {
      return fail(res, 'Payload tidak lengkap');
    }

    const existingEvent = await pool.query(
      `SELECT id FROM webhook_events WHERE event_id = $1`,
      [event_id]
    );
    if (existingEvent.rows.length > 0) {
      return res.status(200).json({ success: true, message: 'Event sudah diproses' });
    }

    await client.query('BEGIN');

    await client.query(
      `INSERT INTO webhook_events (provider, event_id, payload, processed)
       VALUES ('buatqris', $1, $2, TRUE)`,
      [event_id, req.body]
    );

    const txRes = await client.query(
      `SELECT * FROM transactions WHERE provider_ref = $1 AND status = 'PENDING' FOR UPDATE`,
      [reference_id]
    );
    const transaction = txRes.rows[0];

    if (!transaction) {
      await client.query('COMMIT');
      return res.status(200).json({ success: true, message: 'Transaksi tidak ditemukan atau sudah diproses' });
    }

    if (Number(transaction.amount) !== Number(amount)) {
      await client.query(
        `UPDATE transactions SET status = 'FAILED', updated_at = now() WHERE id = $1`,
        [transaction.id]
      );
      await client.query('COMMIT');
      return res.status(200).json({ success: true, message: 'Amount mismatch, transaksi ditandai gagal' });
    }

    if (status === 'SUCCESS') {
      await applyLedgerChange(client, {
        userId: transaction.user_id,
        transactionId: transaction.id,
        type: 'deposit',
        amount: Number(transaction.amount),
        description: 'Deposit QRIS otomatis',
      });

      await client.query(
        `UPDATE transactions SET status = 'SUCCESS', updated_at = now() WHERE id = $1`,
        [transaction.id]
      );
    } else {
      await client.query(
        `UPDATE transactions SET status = 'FAILED', updated_at = now() WHERE id = $1`,
        [transaction.id]
      );
    }

    await client.query('COMMIT');
    return success(res, {}, 'Webhook diproses');
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
}

module.exports = { handleQrisWebhook };