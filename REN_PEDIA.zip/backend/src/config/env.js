require('dotenv').config();

module.exports = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: process.env.PORT || 3000,
  databaseUrl: process.env.DATABASE_URL,
  sessionSecret: process.env.SESSION_SECRET,
  ownerUsername: process.env.OWNER_USERNAME,
  ownerPassword: process.env.OWNER_PASSWORD,
  smtp: {
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    user: process.env.SMTP_USER,
    password: process.env.SMTP_PASSWORD,
    from: process.env.SMTP_FROM,
  },
  buatqris: {
    apiKey: process.env.BUATQRIS_API_KEY,
    secret: process.env.BUATQRIS_SECRET,
  },
  webhookSecret: process.env.WEBHOOK_SECRET,
  publicUrl: process.env.PUBLIC_URL,
  adminWaNumber: process.env.ADMIN_WA_NUMBER,
};