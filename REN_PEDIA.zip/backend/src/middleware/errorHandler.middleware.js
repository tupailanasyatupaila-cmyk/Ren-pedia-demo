module.exports = function errorHandler(err, req, res, next) {
  console.error(err);
  const status = err.status || 500;
  const message = status === 500 ? 'Terjadi kesalahan pada server' : err.message;
  res.status(status).json({ success: false, message });
};