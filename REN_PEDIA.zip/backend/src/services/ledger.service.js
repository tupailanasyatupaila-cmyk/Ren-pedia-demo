const pool = require('../db/pool');

// Semua perubahan saldo WAJIB lewat sini, dalam 1 DB transaction
async function applyLedgerChange(client, { userId, transactionId, type, amount, description }) {
  const balanceRes = await client.query(
    `SELECT balance FROM user_balances WHERE user_id = $1 FOR UPDATE`,
    [userId]
  );
  if (balanceRes.rows.length === 0) {
    throw new Error('Saldo user tidak ditemukan');
  }

  const balanceBefore = Number(balanceRes.rows[0].balance);
  const balanceAfter = balanceBefore + amount;

  if (balanceAfter < 0) {
    const err = new Error('Saldo tidak mencukupi');
    err.status = 400;
    throw err;
  }

  await client.query(
    `UPDATE user_balances SET balance = $1, updated_at = now() WHERE user_id = $2`,
    [balanceAfter, userId]
  );

  await client.query(
    `INSERT INTO balance_ledger (user_id, transaction_id, type, amount, balance_before, balance_after, description)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [userId, transactionId, type, amount, balanceBefore, balanceAfter, description]
  );

  return { balanceBefore, balanceAfter };
}

module.exports = { applyLedgerChange, pool };