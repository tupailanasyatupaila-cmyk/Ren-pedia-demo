const nodemailer = require('nodemailer');
const { smtp } = require('../config/env');

const transporter = nodemailer.createTransport({
  host: smtp.host,
  port: smtp.port,
  secure: false,
  auth: { user: smtp.user, pass: smtp.password },
});

async function sendOtpEmail(to, code) {
  await transporter.sendMail({
    from: smtp.from,
    to,
    subject: 'REN PEDIA - Verification Code',
    html: `
      <div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:24px;">
        <h2 style="color:#0f172a;">REN PEDIA</h2>
        <p style="color:#334155;">Verification Code</p>
        <div style="font-size:28px;font-weight:bold;letter-spacing:4px;color:#2563eb;">${code}</div>
        <p style="color:#64748b;font-size:14px;">Kode berlaku selama 5 menit.</p>
        <p style="color:#94a3b8;font-size:12px;">Jangan pernah memberitahukan kode OTP kamu kepada siapa pun, termasuk pihak yang mengaku sebagai REN PEDIA.</p>
      </div>`,
  });
}

module.exports = { sendOtpEmail };