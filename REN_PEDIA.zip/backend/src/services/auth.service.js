const pool = require('../db/pool');
const { hashPassword, verifyPassword } = require('../utils/hash');
const { createOtp, verifyOtp } = require('./otp.service');
const { sendOtpEmail } = require('./mailer.service');
const { ALLOWED_EMAIL_DOMAIN } = require('../config/constants');

function isValidGmail(email) {
  return typeof email === 'string' && email.toLowerCase().endsWith(ALLOWED_EMAIL_DOMAIN);
}

function mapOtpError(reason) {
  const map = {
    NOT_FOUND: 'Kode OTP tidak ditemukan, minta kode baru',
    EXPIRED: 'Kode OTP sudah kedaluwarsa',
    MAX_ATTEMPTS: 'Terlalu banyak percobaan, minta kode baru',
    MISMATCH: 'Kode OTP salah',
  };
  return map[reason] || 'Kode OTP tidak valid';
}

async function register({ name, username, email, password }) {
  if (!isValidGmail(email)) {
    const err = new Error('Email harus menggunakan domain @gmail.com');
    err.status = 400;
    throw err;
  }

  const existing = await pool.query(
    `SELECT id FROM users WHERE email = $1 OR username = $2`,
    [email, username]
  );
  if (existing.rows.length > 0) {
    const err = new Error('Username atau email sudah terdaftar');
    err.status = 409;
    throw err;
  }

  const passwordHash = await hashPassword(password);
  const { rows } = await pool.query(
    `INSERT INTO users (name, username, email, password_hash)
     VALUES ($1, $2, $3, $4) RETURNING id, name, username, email`,
    [name, username, email, passwordHash]
  );
  const user = rows[0];

  await pool.query(`INSERT INTO user_balances (user_id, balance) VALUES ($1, 0)`, [user.id]);

  const code = await createOtp(user.id, email, 'register');
  await sendOtpEmail(email, code);

  return user;
}

async function verifyRegistrationOtp({ email, code }) {
  const result = await verifyOtp(email, 'register', code);
  if (!result.valid) {
    const err = new Error(mapOtpError(result.reason));
    err.status = 400;
    throw err;
  }
  await pool.query(`UPDATE users SET is_verified = TRUE, updated_at = now() WHERE email = $1`, [email]);
  return { verified: true };
}

async function login({ username, password }) {
  const { rows } = await pool.query(`SELECT * FROM users WHERE username = $1`, [username]);
  const user = rows[0];
  if (!user) {
    const err = new Error('Username atau password salah');
    err.status = 401;
    throw err;
  }
  if (user.is_banned) {
    const err = new Error('Akun ini telah dibanned');
    err.status = 403;
    throw err;
  }
  if (!user.is_verified) {
    const err = new Error('Akun belum diverifikasi. Cek email untuk OTP.');
    err.status = 403;
    throw err;
  }

  const match = await verifyPassword(user.password_hash, password);
  if (!match) {
    const err = new Error('Username atau password salah');
    err.status = 401;
    throw err;
  }

  return { id: user.id, name: user.name, username: user.username, email: user.email };
}

async function requestPasswordReset(email) {
  const { rows } = await pool.query(`SELECT id FROM users WHERE email = $1`, [email]);
  const user = rows[0];
  if (!user) return;
  const code = await createOtp(user.id, email, 'reset_password');
  await sendOtpEmail(email, code);
}

async function resetPassword({ email, code, newPassword }) {
  const result = await verifyOtp(email, 'reset_password', code);
  if (!result.valid) {
    const err = new Error(mapOtpError(result.reason));
    err.status = 400;
    throw err;
  }
  const passwordHash = await hashPassword(newPassword);
  await pool.query(`UPDATE users SET password_hash = $1, updated_at = now() WHERE email = $2`, [passwordHash, email]);
}

module.exports = { register, verifyRegistrationOtp, login, requestPasswordReset, resetPassword };