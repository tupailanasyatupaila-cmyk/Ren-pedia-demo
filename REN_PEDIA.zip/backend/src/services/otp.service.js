const crypto = require('crypto');
const argon2 = require('argon2');
const pool = require('../db/pool');

function generateOtp() {
  return String(crypto.randomInt(100000, 999999));
}

async function createOtp(userId, email, purpose) {
  await pool.query(
    `UPDATE otp_codes SET is_used = TRUE WHERE email = $1 AND purpose = $2 AND is_used = FALSE`,
    [email, purpose]
  );

  const code = generateOtp();
  const codeHash = await argon2.hash(code);
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

  await pool.query(
    `INSERT INTO otp_codes (user_id, email, code_hash, purpose, expires_at)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, email, codeHash, purpose, expiresAt]
  );

  return code;
}

async function verifyOtp(email, purpose, inputCode) {
  const { rows } = await pool.query(
    `SELECT * FROM otp_codes WHERE email = $1 AND purpose = $2 AND is_used = FALSE
     ORDER BY created_at DESC LIMIT 1`,
    [email, purpose]
  );
  const otp = rows[0];
  if (!otp) return { valid: false, reason: 'NOT_FOUND' };
  if (new Date() > otp.expires_at) return { valid: false, reason: 'EXPIRED' };
  if (otp.attempts >= 5) return { valid: false, reason: 'MAX_ATTEMPTS' };

  const match = await argon2.verify(otp.code_hash, inputCode);
  if (!match) {
    await pool.query(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1`, [otp.id]);
    return { valid: false, reason: 'MISMATCH' };
  }

  await pool.query(`UPDATE otp_codes SET is_used = TRUE WHERE id = $1`, [otp.id]);
  return { valid: true };
}

module.exports = { generateOtp, createOtp, verifyOtp };