const axios = require('axios');
const { buatqris } = require('../config/env');

// ⚠️ Endpoint di bawah PLACEHOLDER — ganti sesuai dokumentasi resmi buatqris.site
// begitu kamu punya API key + dokumentasinya. Jangan dipakai produksi sebelum ini diisi benar.
async function createAutoQrisPayment({ amount, transactionId }) {
  if (!buatqris.apiKey || !buatqris.secret) {
    const err = new Error('QRIS otomatis belum dikonfigurasi (API key/secret kosong)');
    err.status = 503;
    throw err;
  }

  // CONTOH struktur request — WAJIB disesuaikan dengan dokumentasi resmi buatqris.site
  const response = await axios.post(
    'https://buatqris.site/api/create-payment', // <-- ganti sesuai dokumentasi resmi
    {
      amount,
      reference_id: transactionId,
    },
    {
      headers: {
        Authorization: `Bearer ${buatqris.apiKey}`,
        'X-Secret': buatqris.secret,
      },
    }
  );

  return {
    qrString: response.data.qr_string,
    qrImageUrl: response.data.qr_image_url,
    providerRef: response.data.reference_id,
    expiresAt: response.data.expires_at,
  };
}

const MANUAL_QRIS_IMAGE_URL = 'https://files.catbox.moe/ncg3ta.jpg';

function getManualQrisInfo(merchantDisplayName) {
  return {
    imageUrl: MANUAL_QRIS_IMAGE_URL,
    merchantName: merchantDisplayName,
  };
}

module.exports = { createAutoQrisPayment, getManualQrisInfo };