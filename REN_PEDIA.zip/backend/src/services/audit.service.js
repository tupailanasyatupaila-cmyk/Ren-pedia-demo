const pool = require('../db/pool');

async function log({ actorId = null, actorRole = null, action, targetType = null, targetId = null, metadata = {}, req }) {
  await pool.query(
    `INSERT INTO audit_logs (actor_id, actor_role, action, target_type, target_id, metadata, ip, user_agent)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [
      actorId,
      actorRole,
      action,
      targetType,
      targetId,
      metadata,
      req?.ip || null,
      req?.headers['user-agent'] || null,
    ]
  );
}

module.exports = { log };