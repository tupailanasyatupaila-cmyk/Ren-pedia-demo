const pool = require('../db/pool');
const { applyLedgerChange } = require('./ledger.service');
const { WITHDRAWAL_FEE } = require('../config/constants');

function calculateFee(method, amount) {
  const rate = WITHDRAWAL_FEE[method] ?? 0;
  const fee = Math.round(amount * rate);
  const netAmount = amount - fee;
  return { fee, netAmount };
}

function maskDestination(method, number) {
  if (method === 'bank') {
    return `BANK ****${number.slice(-4)}`;
  }
  const visible = number.slice(0, 4);
  const last = number.slice(-2);
  return `${visible}${'*'.repeat(Math.max(number.length - 6, 0))}${last}`;
}

async function createWithdrawal({ userId, method, destinationName, destinationNumber, amount }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { fee, netAmount } = calculateFee(method, amount);

    const txRes = await client.query(
      `INSERT INTO transactions (user_id, type, method, amount, fee, net_amount, status)
       VALUES ($1, 'withdrawal', $2, $3, $4, $5, 'PENDING') RETURNING id`,
      [userId, method, amount, fee, netAmount]
    );
    const transactionId = txRes.rows[0].id;

    // Kunci saldo (deduct) di muka, atomic
    await applyLedgerChange(client, {
      userId,
      transactionId,
      type: 'withdrawal_lock',
      amount: -amount,
      description: `Penguncian saldo withdrawal ${method}`,
    });

    const wdRes = await client.query(
      `INSERT INTO withdrawals (transaction_id, destination_name, destination_number, status)
       VALUES ($1, $2, $3, 'PENDING') RETURNING id`,
      [transactionId, destinationName, destinationNumber]
    );

    await client.query('COMMIT');

    return {
      transactionId,
      withdrawalId: wdRes.rows[0].id,
      fee,
      netAmount,
      maskedDestination: maskDestination(method, destinationNumber),
    };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function approveWithdrawal({ withdrawalId, adminId }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const wdRes = await client.query(
      `SELECT w.*, t.id as tx_id, t.status as tx_status
       FROM withdrawals w JOIN transactions t ON t.id = w.transaction_id
       WHERE w.id = $1 FOR UPDATE`,
      [withdrawalId]
    );
    const withdrawal = wdRes.rows[0];
    if (!withdrawal) throw Object.assign(new Error('Withdrawal tidak ditemukan'), { status: 404 });
    if (withdrawal.status !== 'PENDING') throw Object.assign(new Error('Withdrawal sudah diproses'), { status: 409 });

    await client.query(
      `UPDATE transactions SET status = 'SUCCESS', updated_at = now() WHERE id = $1`,
      [withdrawal.tx_id]
    );
    await client.query(
      `UPDATE withdrawals SET status = 'SUCCESS', processed_by = $1, processed_at = now() WHERE id = $2`,
      [adminId, withdrawalId]
    );

    const receiptNumber = `RCP-${Date.now()}`;
    await client.query(
      `INSERT INTO receipts (withdrawal_id, receipt_number) VALUES ($1, $2)`,
      [withdrawalId, receiptNumber]
    );

    await client.query('COMMIT');
    return { receiptNumber };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function rejectWithdrawal({ withdrawalId, adminId, reason }) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const wdRes = await client.query(
      `SELECT w.*, t.id as tx_id, t.user_id, t.amount
       FROM withdrawals w JOIN transactions t ON t.id = w.transaction_id
       WHERE w.id = $1 FOR UPDATE`,
      [withdrawalId]
    );
    const withdrawal = wdRes.rows[0];
    if (!withdrawal) throw Object.assign(new Error('Withdrawal tidak ditemukan'), { status: 404 });
    if (withdrawal.status !== 'PENDING') throw Object.assign(new Error('Withdrawal sudah diproses'), { status: 409 });

    // Refund saldo yang sudah dikunci
    await applyLedgerChange(client, {
      userId: withdrawal.user_id,
      transactionId: withdrawal.tx_id,
      type: 'withdrawal_refund',
      amount: Number(withdrawal.amount),
      description: `Refund withdrawal ditolak: ${reason}`,
    });

    await client.query(
      `UPDATE transactions SET status = 'REJECTED', updated_at = now() WHERE id = $1`,
      [withdrawal.tx_id]
    );
    await client.query(
      `UPDATE withdrawals SET status = 'REJECTED', processed_by = $1, processed_at = now() WHERE id = $2`,
      [adminId, withdrawalId]
    );

    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { calculateFee, maskDestination, createWithdrawal, approveWithdrawal, rejectWithdrawal };