const argon2 = require('argon2');

async function hashPassword(plain) {
  return argon2.hash(plain);
}

async function verifyPassword(hash, plain) {
  return argon2.verify(hash, plain);
}

module.exports = { hashPassword, verifyPassword };