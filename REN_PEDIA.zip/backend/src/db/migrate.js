const fs = require('fs');
const path = require('path');
const pool = require('./pool');

async function runMigrations() {
  const migrationsDir = path.join(__dirname, '../../../database/migrations');
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();

  console.log(`Ditemukan ${files.length} file migrasi`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS _migrations_history (
      id SERIAL PRIMARY KEY,
      filename VARCHAR(255) UNIQUE NOT NULL,
      applied_at TIMESTAMPTZ DEFAULT now()
    )
  `);

  for (const file of files) {
    const { rows } = await pool.query(
      `SELECT id FROM _migrations_history WHERE filename = $1`,
      [file]
    );
    if (rows.length > 0) {
      console.log(`⏭  Skip (sudah dijalankan): ${file}`);
      continue;
    }

    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    console.log(`▶  Menjalankan: ${file}`);

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(sql);
      await client.query(
        `INSERT INTO _migrations_history (filename) VALUES ($1)`,
        [file]
      );
      await client.query('COMMIT');
      console.log(`✅ Berhasil: ${file}`);
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(`❌ Gagal: ${file}`, err.message);
      process.exit(1);
    } finally {
      client.release();
    }
  }

  console.log('Semua migrasi selesai.');
  await pool.end();
}

runMigrations().catch((err) => {
  console.error('Migration error:', err);
  process.exit(1);
});