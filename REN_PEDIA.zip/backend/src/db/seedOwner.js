const pool = require('./pool');
const { hashPassword } = require('../utils/hash');
const env = require('../config/env');

async function seedOwner() {
  if (!env.ownerUsername || !env.ownerPassword) {
    console.error('❌ OWNER_USERNAME atau OWNER_PASSWORD belum diset di environment variables');
    process.exit(1);
  }

  const { rows } = await pool.query(
    `SELECT id FROM admins WHERE username = $1`,
    [env.ownerUsername]
  );

  if (rows.length > 0) {
    console.log(`⏭  Owner "${env.ownerUsername}" sudah ada, skip seeding.`);
    await pool.end();
    return;
  }

  const passwordHash = await hashPassword(env.ownerPassword);

  await pool.query(
    `INSERT INTO admins (username, password_hash, role, permissions)
     VALUES ($1, $2, 'OWNER', $3)`,
    [env.ownerUsername, passwordHash, JSON.stringify(['*'])]
  );

  console.log(`✅ Owner "${env.ownerUsername}" berhasil dibuat.`);
  await pool.end();
}

seedOwner().catch((err) => {
  console.error('Seed owner error:', err);
  process.exit(1);
});