const { Pool } = require('pg');
const { databaseUrl, nodeEnv } = require('../config/env');

const pool = new Pool({
  connectionString: databaseUrl,
  ssl: nodeEnv === 'production' ? { rejectUnauthorized: false } : false,
});

pool.on('error', (err) => console.error('Unexpected DB error', err));

module.exports = pool;