const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const path = require('path');

const pool = require('./db/pool');
const env = require('./config/env');
const { SESSION_MAX_AGE_MS } = require('./config/constants');
const errorHandler = require('./middleware/errorHandler.middleware');

const authRoutes = require('./routes/auth.routes');
const depositRoutes = require('./routes/deposit.routes');
const webhookRoutes = require('./routes/webhook.routes');
const withdrawalRoutes = require('./routes/withdrawal.routes');
const adminRoutes = require('./routes/admin.routes');
const ownerRoutes = require('./routes/owner.routes');

const app = express();

app.use(helmet());

app.use(cors({
  origin: env.publicUrl,
  credentials: true,
}));

app.use(express.json());
app.use(cookieParser());

app.use(session({
  store: new pgSession({
    pool,
    tableName: 'sessions',
  }),
  secret: env.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: env.nodeEnv === 'production',
    sameSite: 'lax',
    maxAge: SESSION_MAX_AGE_MS,
  },
}));

app.use(
  express.static(
    path.join(__dirname, '../../frontend/public')
  )
);

// AUTH
app.use('/api/auth', authRoutes);

// DEPOSIT
app.use('/api/deposit', depositRoutes);

// WEBHOOK
app.use('/api/webhook', webhookRoutes);

// WITHDRAWAL
app.use('/api/withdraw', withdrawalRoutes);

// ADMIN
app.use('/api/admin', adminRoutes);

// OWNER
app.use('/api/owner', ownerRoutes);

// ERROR HANDLER HARUS PALING BAWAH
app.use(errorHandler);

module.exports = app;