# REN PEDIA

Platform pembayaran/saldo digital — full-stack production-ready.

## 1. Install
\`\`\`bash
cd backend
npm install
\`\`\`

## 2. Setup PostgreSQL
Buat database PostgreSQL (lokal atau via Railway Postgres plugin).
Salin connection string ke `DATABASE_URL`.

## 3. Setup .env
\`\`\`bash
cp .env.example .env
\`\`\`
Isi semua variabel: `DATABASE_URL`, `SESSION_SECRET`, `OWNER_USERNAME`, `OWNER_PASSWORD`,
kredensial SMTP Brevo, `BUATQRIS_API_KEY`/`BUATQRIS_SECRET`, `WEBHOOK_SECRET`, `PUBLIC_URL`.

## 4. Migration
\`\`\`bash
npm run migrate
\`\`\`

## 5. Seed Owner
\`\`\`bash
npm run seed
\`\`\`

## 6. Local development
\`\`\`bash
npm start
\`\`\`
Server jalan di `http://localhost:3000`.

## 7. Build
Tidak ada build step (Node.js murni, tidak pakai transpiler).

## 8. Railway Deployment
1. Push project ke GitHub.
2. Buat project baru di Railway, connect ke repo.
3. Tambahkan plugin PostgreSQL — Railway otomatis isi `DATABASE_URL`.
4. Set root directory ke `backend` (Settings → Root Directory).
5. Set Start Command: `npm start`.

## 9. Railway Variables
Set semua variabel di `.env.example` lewat tab **Variables** di Railway.
`PORT` sudah otomatis di-inject Railway — jangan hardcode.

## 10. SMTP Brevo Setup
1. Daftar di brevo.com, buat SMTP key.
2. Isi `SMTP_USER` dan `SMTP_PASSWORD` dengan kredensial SMTP (bukan API key dashboard).
3. `SMTP_FROM` harus pakai domain yang sudah diverifikasi di Brevo.

## 11. QRIS Provider Setup (buatqris.site)
1. Daftar dan ambil API key + secret dari buatqris.site.
2. Baca dokumentasi resmi mereka untuk endpoint & format payload yang benar.
3. Update `src/services/qris.service.js` — bagian endpoint masih placeholder,
   sesuaikan dengan dokumentasi resmi sebelum dipakai produksi.

## 12. Webhook Setup
Setelah deploy, daftarkan URL webhook ke buatqris.site:
\`\`\`
https://<domain-railway-kamu>/api/webhook/qris
\`\`\`
Pastikan `WEBHOOK_SECRET` di .env sama dengan yang dikonfigurasi di dashboard provider.

## 13. Production Security Checklist
- [ ] `SESSION_SECRET` random & panjang (min 32 karakter)
- [ ] `OWNER_PASSWORD` diganti dari default setelah seed pertama
- [ ] HTTPS aktif (Railway otomatis kasih TLS)
- [ ] `NODE_ENV=production`
- [ ] Semua secret hanya di environment variables, tidak ada di kode
- [ ] Rate limiting aktif di endpoint auth & OTP
- [ ] Backup database berkala
- [ ] Test webhook idempotency sebelum go-live