INSERT INTO settings (key, value) VALUES
  ('withdrawal_fee', '{"ewallet": 0.03, "bank": 0.035, "manual": 0}')
  ON CONFLICT (key) DO NOTHING;

INSERT INTO settings (key, value) VALUES
  ('maintenance', '{"enabled": false, "message": ""}')
  ON CONFLICT (key) DO NOTHING;

INSERT INTO payment_methods (code, name, type) VALUES
  ('dana', 'DANA', 'ewallet'),
  ('ovo', 'OVO', 'ewallet'),
  ('gopay', 'GoPay', 'ewallet'),
  ('shopeepay', 'ShopeePay', 'ewallet'),
  ('bank_transfer', 'Transfer Bank', 'bank'),
  ('manual', 'Manual Withdrawal', 'manual')
  ON CONFLICT (code) DO NOTHING;